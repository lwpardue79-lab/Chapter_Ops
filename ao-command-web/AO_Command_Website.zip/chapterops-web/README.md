# ChapterOps Lite Web Trial

This is a no-install website version of ChapterOps Lite. It is designed for a weekend pilot with a treasurer or executive officer.

## How to use it this weekend

1. Open `index.html` in a browser.
2. Go to Settings and update the chapter / organization name.
3. Add 5–10 real members.
4. Add one real event.
5. Use Attendance to record a test check-in.
6. Add or update dues rows with the treasurer.
7. Add one reimbursement request.
8. Review Dashboard.
9. Open Weekly Report and copy or print it.
10. Use Export to save a JSON backup of the trial data.

## What works now

- Dashboard metrics
- Member database
- Event tracker
- Attendance check-in with duplicate check-in updating
- Dues and balance tracking
- Reimbursement tracking
- Weekly executive report
- Settings
- Searchable tables
- Local browser storage
- JSON import/export backup

## Important limitation

This version stores data in the browser on the computer where it is used. For a real multi-officer product, the next step is a backend such as Supabase with login, roles, and a shared database.

