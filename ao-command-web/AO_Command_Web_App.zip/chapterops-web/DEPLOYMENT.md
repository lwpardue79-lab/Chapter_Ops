# ChapterOps Lite Deployment Path

## Fastest public URL

Use Vercel as a static site:

1. Create a GitHub repo.
2. Push the `chapterops-web` folder.
3. In Vercel, import the repo.
4. Set the project root to `chapterops-web`.
5. Leave build command blank.
6. Leave output directory blank.
7. Deploy.

That gives you a public Vercel URL.

## Important public-site warning

The current version stores data in each browser's local storage. That is fine for a demo URL, but not for real shared chapter operations. For real use by multiple officers, build the Supabase version next.

## Real production architecture

- Frontend: Next.js app using this UI
- Auth: Supabase Auth
- Database: Supabase Postgres
- Tables: organizations, members, events, attendance, dues, reimbursements, reports, settings
- Roles: admin, president, treasurer, secretary, read-only advisor
- Storage: receipt uploads
- Email: weekly report via Resend, SendGrid, or Supabase Edge Function
- Payments: Stripe for dues collection and reconciliation

## Suggested build order

1. Convert this static UI into Next.js pages/components.
2. Add Supabase schema and Row Level Security.
3. Add login and organization-level roles.
4. Move local state to Supabase queries/mutations.
5. Add receipt upload.
6. Add hosted executive report emails.
7. Add Stripe dues payment links.

